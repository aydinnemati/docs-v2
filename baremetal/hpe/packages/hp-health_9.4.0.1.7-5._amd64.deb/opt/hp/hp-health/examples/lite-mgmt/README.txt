
README.txt for hpsysmon "lite management"

===========================================================================
Please read the accompanying License Agreement in the COPYING.txt file.
By accepting this package, you are bound by this agreement.
===========================================================================

This sample script files provides a method to monitor HP ProLiant 300 - 700
series servers using the tools provided by the hp-health RPM. This is just
a sample script that highlights the following capabilities:

o hplog(7)
o hpasmcli(4)


This script relies on a "polled" interface.  For an event driven interface,
a simple program could be written to monitor the "syslog" (or the
"/var/log/messages" file) for messages from "hpasm" or "cmaeventd" an
then run this script to get an update.

This script and the included configuration file are a base example and
the developer is expected to customize these scripts for their unique
environment.

The recommend HP Server Management Packages for using these scripts are:

o hp-wdt            : HP Hardware Watchdog Timer driver
o hp-OpenIPMI       : HP IPMI Driver Stack
o hp-health         : HP Base system Management
o hp-snmp-agents    : HP agent support which includes storage monitoring.

NOTE:  The "hp-snmp-agents" require the "net-snmp-libs" to be installed. The
"net-snmp" RPM, however, does not have to be installed.

The hp-OpenIPMI package is recommended on all HP ProLiant G5 servers for better
performance and reliability.  See the man page hp-OpenIPMI(4) for further
details. NOTE:  The hp-health package will work with the IPMI drivers that
ship in the Linux distribution.

The hp-wdt package is recommended to get advanced NMI processing on the HP
ProLiant server.  See the man page hp-wdt(4) for further details.

The hp-snmp-agents is only needed if you desire monitoring of storage
devices attached to an HP SmartArray controller. While designed to work
with the "net-snmp" package, the core storage agents will operate 
independently of the SNMP networking protocol.

To configure a simple management solution:

1.  Install the hp-wdt RPM
2.  Install the hp-OpenIPMI RPM.
3.  Install the hp-health RPM.
4.  If storage monitoring desired, install the hp-snmp-agents RPM.
5.  If hp-snmp-agents is installed, copy the "cma.conf.nosnmp" file
    to "/opt/hp/hp-snmp-agents/cma.conf"

Additional system management information may be obtained using the
standard Linux utilities "dmidecode(8)", "lspci(8)" and for networking
"ethtool(8)".

